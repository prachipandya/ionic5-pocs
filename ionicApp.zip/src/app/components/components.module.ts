// import { NgModule} from '@angular/core';
// import {FrameworkMessageComponent} from './framework-message/framework-message.component';

// @NgModule({
//   declarations: [FrameworkMessageComponent],
//   exports: [FrameworkMessageComponent]
// })
// export class ComponentsModule {
// }
