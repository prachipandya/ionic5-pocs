import { Component, OnInit, Input, Output } from '@angular/core';

@Component({
  selector: 'app-framework-message',
  templateUrl: './framework-message.component.html',
  styleUrls: ['./framework-message.component.scss'],
})
export class FrameworkMessageComponent implements OnInit {

  private message:string;
  constructor() { }

  ngOnInit() {}

  onSearch =  (searchText:string) => {
    this.message=searchText;
  }
}
