import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Customer } from './customer.model';

@Injectable()
export class CustomerService {

    private baseUrl: string;
    constructor(private http: HttpClient) 
    {
        this.baseUrl = environment.baseUrl;
    }
    
    // HttpClient API get() method => Fetch employees list
    public getCustomerList(): Observable<Customer[]> {
        return this.http.get<Customer[]>(this.baseUrl + '/employees');
    }

    // HttpClient API get() method => Fetch searched employee details
    public getCustomer(employeeID: string): Observable<Customer[]> {
        return this.http.get<Customer[]>(this.baseUrl + '/employees?q='+employeeID);
    }
}