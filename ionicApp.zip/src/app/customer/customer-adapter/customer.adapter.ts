import { Injectable } from '@angular/core';
import { Customer } from '../customer.model'

@Injectable()
export class CustomerAdapter {
    /** This method is used to transform response object into T object. */
    public toResponse(item: Customer): Customer{
        const customer: Customer= new Customer(
                item.id,            
                item.name,                 
                item.email          
        );
        return customer;
    }

    /** This method is used to transform T object into request object. */
    public toRequest(item: Customer): Customer{
        const customer: Customer= new Customer(
            item.id,            
            item.name,                 
            item.email  
        );
        return customer;
    }
}