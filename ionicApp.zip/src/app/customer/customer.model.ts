export class Customer {
      /** id  of Employee */
      public id: string;
      /** name  of Employee */
      public name: string;
      /** email  of Employee */
      public email: string;

      constructor(
        id?: string,   
        name?: string,   
        email?: string) {
            this.id= id;
            this.name= name;
            this.email= email;
        }
}