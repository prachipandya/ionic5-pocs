import { NgModule } from '@angular/core';

import { CustomerService } from './customer.service';
import { CustomerContainerComponent } from './customer-container/customer.container';
import { CustomerPresentationComponent } from './customer-container/customer-presentation/customer.presentation';

import { CommonModule } from '@angular/common';
import { CustomerRoutingModule } from './customer.routing';

@NgModule({
    declarations: [
      CustomerContainerComponent,
      CustomerPresentationComponent
    ],
    imports: [
      CustomerRoutingModule,
      CommonModule 
    ],
    providers: [
      CustomerService
    ],
    entryComponents:[]
})

export class CustomerModule {
}