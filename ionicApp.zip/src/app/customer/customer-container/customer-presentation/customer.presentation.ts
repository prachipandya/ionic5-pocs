import { Component, Input, Output, EventEmitter } from '@angular/core';

import { CustomerPresenter } from '../customer-presenter/customer.presenter';
import { Customer } from '../../customer.model';
import { takeUntil } from 'rxjs/operators';
import { Subject } from 'rxjs';

@Component({
    selector: 'app-customer-ui',
    templateUrl: './customer.presentation.html',
    viewProviders: [CustomerPresenter],
})

export class CustomerPresentationComponent {
    /** create for getter setter */
    private _customers: Customer[];
    private searchText:string;
    public isSearchValid:boolean;

    /** Subject for destroy */
    private destroy: Subject<void>;

    constructor(public customerPresenter: CustomerPresenter) {
        this.destroy = new Subject();
        this.getSearchCustomer = new EventEmitter<string>();
    }

    @Input() public set customers(customers: Customer[]) {
        this._customers = customers;
    };

    public get customers(): Customer[] {
        return this._customers;
    }

    /** This property is used for emit data to container component */
    @Output() public getSearchCustomer: EventEmitter<string>;

    public ngOnInit(): void {
        //By default set search validation as true so error message will not be dispalyed
        this.isSearchValid=true;

        // This will subscribe the getSearchCustomer event and emit to container component
        this.customerPresenter.isSearchValid$.pipe(takeUntil(this.destroy)).subscribe((isSearchValid:boolean) => {
            if(isSearchValid)
            {
                this.isSearchValid=true;
                this.getSearchCustomer.emit(this.searchText);
            }   
            else
            {
                this.isSearchValid=false;
            }
        });
    }

    public onSearch(searchText:string) :void {
        this.searchText=searchText;
        this.customerPresenter.onSearch(searchText);   
    }

    public ngOnDestroy(): void {
        this.destroy.next();
        this.destroy.complete();
    }
}