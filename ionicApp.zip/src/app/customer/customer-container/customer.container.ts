import { Component } from '@angular/core';

import { Observable } from 'rxjs';
import { Customer } from '../customer.model';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-customer-container',
  templateUrl: './customer.container.html'
})

export class CustomerContainerComponent {
  /** This is a observable which passes the list of employee to its child component */
  public customer$: Observable<Customer[]>;

  constructor(private customerService: CustomerService)
  {
    this.customer$ = this.customerService.getCustomerList();
  }

  /** This method is used to get data from service.ts file  */
  public getSearchCustomer(searchText: string): void {    
    this.customer$ = this.customerService.getCustomer(searchText);
  }
}