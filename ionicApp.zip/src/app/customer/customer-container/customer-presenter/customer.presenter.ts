import { Injectable } from '@angular/core';
import { Subject, Observable } from 'rxjs';

@Injectable()
export class CustomerPresenter {
    /** This is used for subscribing the value of subject add */
    public isSearchValid$: Observable<boolean>;

    constructor() {
        this.isSearchValid$ = this.isSearchValid.asObservable();
    }

    private isSearchValid: Subject<boolean> = new Subject();

    public onSearch(searchText: string): void {
        if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(searchText))
            this.isSearchValid.next(true);
        else
            this.isSearchValid.next(false);
    }
}