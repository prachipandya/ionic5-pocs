import { NgModule, Injector } from '@angular/core';
import { createCustomElement } from '@angular/elements';

import { BrowserModule } from '@angular/platform-browser';
import { RouteReuseStrategy } from '@angular/router';

import { IonicModule, IonicRouteStrategy } from '@ionic/angular';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { SpeechRecognition } from '@ionic-native/speech-recognition/ngx';
import { environment } from 'src/environments/environment';
import { FrameworkMessageComponent } from './components/framework-message/framework-message.component';

@NgModule({
  declarations: [AppComponent,FrameworkMessageComponent],
  entryComponents: [FrameworkMessageComponent],
  imports: [BrowserModule, IonicModule.forRoot(), AppRoutingModule],
  providers: [
    StatusBar,
    SplashScreen,
    SpeechRecognition,
    { provide: RouteReuseStrategy, useClass: IonicRouteStrategy }
  ],
  bootstrap: environment.widget? [] : [AppComponent]
})
export class AppModule {
  constructor(private injector: Injector) {}

  ngDoBootstrap() {
    const custElement = createCustomElement(FrameworkMessageComponent,{injector:this.injector});
    customElements.define('quaries-message',custElement);
  }
}
