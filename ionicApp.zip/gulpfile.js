var gulp = require('gulp'),
    gp_concat = require('gulp-concat');
    //gp_rename = require('gulp-rename'),
    //gp_uglify = require('gulp-uglify');

    // gulp.task('default', function() {
    //     console.log("Concating and moving all the css files in styles folder");
    //     gulp.src(['./dist/*.js'])
    //     .pipe(gp_concat('concat.js'))
    //     .pipe(gulp.dest('dist'))
    //   });

gulp.task('js-fef', function(){
    return gulp.src(['./www/*.js'])
        .pipe(gp_concat('concat.js'))
        .pipe(gulp.dest('www'))
        //.pipe(gp_rename('common-element.js'))
        //.pipe(gp_uglify())
        .pipe(gulp.dest('www'));
});

gulp.task('default', gulp.series('js-fef'));